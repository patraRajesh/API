from django.db import models
from django.utils.timezone import now
from django_mysql.models import ListCharField
from django.db.models import CharField, Model
# Create your models here.
def validate_positive(val):
	if val<0:
		raise ValidationError("Audio Duration - invalid")
	return val



class Song(models.Model):
	ID=models.IntegerField(primary_key=True,blank=False)
	name=models.CharField(max_length=100,blank=False)
	duration=models.IntegerField(validators =[validate_positive],blank=False)
	upload_time=models.DateTimeField(default=now,blank=False)

class Podcast(models.Model):
	ID=models.IntegerField(primary_key=True,blank=False)
	name=models.CharField(max_length=100,blank=False)
	duration=models.IntegerField(validators =[validate_positive],blank=False)
	upload_time=models.DateTimeField(default=now,blank=False)
	host=models.CharField(max_length=100,blank=False)
	participants=ListCharField(base_field=CharField(max_length=10),size=10,max_length=(10 * 11),blank=True)

class Audiobook(models.Model):
	ID=models.IntegerField(primary_key=True,blank=False)
	name=models.CharField(max_length=100,blank=False)
	duration=models.IntegerField(validators =[validate_positive],blank=False)
	upload_time=models.DateTimeField(default=now,blank=False)
	author=models.CharField(max_length=100,blank=False)
	narrator=models.CharField(max_length=100,blank=False)