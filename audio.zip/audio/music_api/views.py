from django.shortcuts import render
from .models import Song,Audiobook,Podcast
from django.views.generic import ListView,DetailView,TemplateView
from django.http import HttpResponse,JsonResponse
import json,ast
from django.views.decorators.csrf import csrf_exempt
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status,permissions
from .serializers import SongSerializer,PodcastSerializer,AudiobookSerializer
from django.utils.timezone import now
# Create your views here.

functions={Song:SongSerializer,Podcast:PodcastSerializer,Audiobook:AudiobookSerializer}

def model_select(productname):
	if productname=="song":
		data = Song
	elif productname=="audiobook":
		data = Audiobook
	elif productname=="podcast":
		data = Podcast
	else:
		data = 'not found'
	return data


#Insert-done
class CreateApiView(APIView):

    def get_object(self,model_, pk):
        try:
        	if pk:
        		return model_.objects.get(ID=pk)
        	return None
        except:
            return None

    @csrf_exempt
    def post(self, request,*args, **kwargs):
	    try:
	        model_=model_select(request.data["audioFileType"].lower())
	        try:
	        	data_=ast.literal_eval(request.data["audioFileMetadata"])
	        except:
	        	data_=request.data["audioFileMetadata"]
	        audio_instance = self.get_object(model_,data_['ID'])
	        if audio_instance:
	            return Response(
	                {"res": "Object with id already exists / table not exists"}, 
	                status=status.HTTP_400_BAD_REQUEST
	            )
	        serializer = functions[model_](data=data_)
	        if serializer.is_valid():
	            serializer.save()
	            return Response(serializer.data, status=status.HTTP_200_OK)
	        return Response(serializer.error,status=status.HTTP_400_BAD_REQUEST)
	    except Exception as e:
	        return Response(status=status.HTTP_400_BAD_REQUEST)


# Retrieve-done
class DetailApiView(APIView):

    def get_object(self,model_, pk):
        try:
        	if pk:
        		return model_.objects.get(ID=pk)
        	return model_.objects.all()
        except model_.DoesNotExist:
            return None

    
    def get(self, request, slug, pk=0):
        model_=model_select(slug.lower())
        audio_instance = self.get_object(model_,pk)
        if not audio_instance:
            return Response({"res": "Object with id does not exists"},status=status.HTTP_400_BAD_REQUEST)
        if pk:
        	serializer = functions[model_](audio_instance)
        else:
        	serializer = functions[model_](audio_instance, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    # Update-done
class UpdateApiView(APIView):

    def get_object(self,model_, pk):
        try:
        	if pk:
        		return model_.objects.get(ID=pk)
        	return None
        except model_.DoesNotExist:
            return None

    @csrf_exempt
    def post(self, request,*args, **kwargs):
        
        model_=model_select(self.kwargs['slug'].lower())
        try:
            data_=ast.literal_eval(request.data["audioFileMetadata"])
        except:
            data_=request.data["audioFileMetadata"]
        audio_instance = self.get_object(model_,kwargs['pk'])
        if not audio_instance or data_['ID']!=audio_instance.pk:
            return Response(
                {"res": "Object with id does not exists"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        data_['upload_time']=now()
        serializer = functions[model_](instance = audio_instance, data=data_,partial = True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    # 5. Delete-done
class DeleteApiView(APIView):

    def get_object(self,model_, pk):
        try:
        	if pk:
        		return model_.objects.get(ID=pk)
        	return None
        except model_.DoesNotExist:
            return None
    def get(self, request, slug, pk):
        audio_instance = self.get_object(model_select(self.kwargs['slug'].lower()),pk)
        if not audio_instance:
            return Response(
                {"res": "Object does not exists"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        audio_instance.delete()
        return Response(
            {"res": "Object deleted!"},
            status=status.HTTP_200_OK
        )


