from rest_framework import serializers
from .models import Song,Audiobook,Podcast

class SongSerializer(serializers.ModelSerializer):
    class Meta:
        model = Song
        fields = ['ID', 'name', 'duration','upload_time']

class AudiobookSerializer(serializers.ModelSerializer):
    class Meta:
        model = Audiobook
        fields = ['ID', 'name', 'duration','author','narrator','upload_time']

class PodcastSerializer(serializers.ModelSerializer):
    class Meta:
        model = Podcast
        fields = ['ID', 'name', 'duration','host','upload_time']
        participants=serializers.ListField(child = serializers.CharField())
        extra_kwargs = {'host': {'required': True},'name': {'required': True},'duration': {'required': True},'participants': {'required': False}}