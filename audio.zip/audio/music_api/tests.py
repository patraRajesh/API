from django.test import TestCase
from .models import Song,Audiobook,Podcast
import json
from rest_framework import status
from django.test import TestCase, Client
from django.urls import reverse
from music_api.views import DetailApiView,UpdateApiView,CreateApiView,DeleteApiView
from .serializers import SongSerializer,PodcastSerializer,AudiobookSerializer
client = Client()


class SongTest(TestCase):
    
    def setUp(self):
        Song.objects.create(ID=100,name='a',duration=1010)
        Song.objects.create(ID=101,name='b',duration=1001)

    def test_normal(self):
        a = Song.objects.get(name='a')
        b = Song.objects.get(name='b')
        self.assertEqual(
            a.ID, 100)
        self.assertEqual(
            b.duration, 1001)

#2
class GetAllSongTest(TestCase):

    def setUp(self):
        Song.objects.create(ID=102,name='c',duration=1010)
        Song.objects.create(ID=103,name='d',duration=1001)

    def test_get_all(self):
        response = client.get(reverse('DetailApiView',args=["song"]))
        serializer = SongSerializer(Song.objects.all(), many=True)
        self.assertEqual(response.data, serializer.data)
        self.assertEqual(response.status_code, status.HTTP_200_OK)


class GetSingleSongTest(TestCase):

    def setUp(self):
        self.x=Song.objects.create(ID=102,name='c',duration=1010)
        self.y=Song.objects.create(ID=103,name='d',duration=1001)

    def test_get_valid_single(self):
        response = client.get(
            reverse('DetailApiView', kwargs={'pk': self.x.pk,'slug':"song"}))
        serializer = SongSerializer(Song.objects.get(pk=self.x.pk))
        self.assertEqual(response.data, serializer.data)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_get_invalid_single(self):
        response = client.get(
            reverse('DetailApiView', kwargs={'pk': 30,'slug':"song"}))
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
#3 check
class CreateNewSongTest(TestCase):

    def setUp(self):
        self.valid_payload = {
            'audioFileMetadata':"{'ID':102111,'name':'c','duration':1010}",'audioFileType':'Song'
        }
        self.invalid_payload = {
             'audioFileMetadata':{'ID':102111,'name':'c','duration':1010},'audioFileType':'Songs'
        }

    def test_create_valid(self):
        response = client.post(
            reverse('CreateApiView'),
            data=json.dumps(self.valid_payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_create_invalid(self):
        response = client.post(
            reverse('CreateApiView'),
            data=json.dumps(self.invalid_payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

#4
class UpdateSingleSongTest(TestCase):

    def setUp(self):
        self.x=Song.objects.create(ID=100,name='a',duration=1010)
        self.y=Song.objects.create(ID=101,name='b',duration=1001)
        self.valid_payload = {
            'audioFileMetadata':"{'ID':100,'name':'c','duration':210}",'audioFileType':'Song'
        }
        self.invalid_payload = {
             'audioFileMetadata':"{'ID':102111,'name':'c','duration':1010}",'audioFileType':'Songs'
        }

    def test_valid_update(self):
        response = client.post(
            reverse('UpdateApiView', kwargs={'pk': self.x.pk,'slug':"song"}),
            data=json.dumps(self.valid_payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_invalid_update(self):
        response = client.post(
            reverse('UpdateApiView', kwargs={'pk': self.x.pk,'slug':"song"}),
            data=json.dumps(self.invalid_payload),
            content_type='application/json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
#5
class DeleteSingleSongTest(TestCase):

    def setUp(self):
        self.x=Song.objects.create(ID=100,name='a',duration=1010)
        self.y=Song.objects.create(ID=101,name='b',duration=1001)

    def test_valid_delete(self):
        response = client.get(
            reverse('DeleteApiView', kwargs={'pk': self.x.pk,'slug':"song"}))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_invalid_delete(self):
        response = client.get(
            reverse('DeleteApiView', kwargs={'pk': 99,'slug':"song"}))
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)


#-------------------------podcast-----------------------------

class PodcastTest(TestCase):
    
    def setUp(self):
        Podcast.objects.create(ID=1002,name='a',duration=1010,host='ra',participants="['a','b','c']")
        Podcast.objects.create(name='b',duration=1001,host='ra')

    def test_normal(self):
        a = Podcast.objects.get(name='a')
        b = Podcast.objects.get(name='b')
        self.assertEqual(
            a.ID, 1002)
        self.assertEqual(
            b.duration, 1001)

#2
class GetAllPodcastTest(TestCase):

    def setUp(self):
        Podcast.objects.create(ID=100,duration=1010,host='ra',participants="['a','b','c']")
        Podcast.objects.create(ID=103,name='d',duration=1001)

    def test_get_all(self):
        response = client.get(reverse('DetailApiView',args=["Podcast"]))
        serializer = PodcastSerializer(Podcast.objects.all(), many=True)
        self.assertEqual(response.data, serializer.data)
        self.assertEqual(response.status_code, status.HTTP_200_OK)


class GetSinglePodcastTest(TestCase):

    def setUp(self):
        self.x=Podcast.objects.create(ID=102,name='c',duration=1010)
        self.y=Podcast.objects.create(ID=103,name='d',duration=1001)

    def test_get_valid_single(self):
        response = client.get(
            reverse('DetailApiView', kwargs={'pk': self.x.pk,'slug':"Podcast"}))
        serializer = PodcastSerializer(Podcast.objects.get(pk=self.x.pk))
        self.assertEqual(response.data, serializer.data)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_get_invalid_single(self):
        response = client.get(
            reverse('DetailApiView', kwargs={'pk': 30,'slug':"Podcast"}))
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
#3 check
class CreateNewPodcastTest(TestCase):

    def setUp(self):
        self.valid_payload = {
            'audioFileMetadata':"{'ID':102111,'name':'c','duration':1010,'host':'ee','participants':['a','b','c']}",'audioFileType':'Podcast'
        }
        self.invalid_payload = {
             'audioFileMetadata':{'ID':102111,'name':'c','duration':1010,'host':'ee'},'audioFileType':'Podcasts'
        }

    def test_create_valid(self):
        response = client.post(
            reverse('CreateApiView'),
            data=json.dumps(self.valid_payload),
            content_type='application/json'
        )
        
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_create_invalid(self):
        response = client.post(
            reverse('CreateApiView'),
            data=json.dumps(self.invalid_payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

#4
class UpdateSinglePodcastTest(TestCase):

    def setUp(self):
        self.x=Podcast.objects.create(ID=100,name='a',duration=1010)
        self.y=Podcast.objects.create(ID=101,name='b',duration=1001)
        self.valid_payload = {
            'audioFileMetadata':"{'ID':100,'name':'c','duration':210}",'audioFileType':'Podcast'
        }
        self.invalid_payload = {
             'audioFileMetadata':"{'ID':102111,'name':'c','duration':1010}",'audioFileType':'Podcasts'
        }

    def test_valid_update(self):
        response = client.post(
            reverse('UpdateApiView', kwargs={'pk': self.x.pk,'slug':"Podcast"}),
            data=json.dumps(self.valid_payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_invalid_update(self):
        response = client.post(
            reverse('UpdateApiView', kwargs={'pk': self.x.pk,'slug':"Podcast"}),
            data=json.dumps(self.invalid_payload),
            content_type='application/json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
# #5
class DeleteSinglePodcastTest(TestCase):

    def setUp(self):
        self.x=Podcast.objects.create(ID=100,name='a',duration=1010)
        self.y=Podcast.objects.create(ID=101,name='b',duration=1001)

    def test_valid_delete(self):
        response = client.get(
            reverse('DeleteApiView', kwargs={'pk': self.x.pk,'slug':"Podcast"}))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_invalid_delete(self):
        response = client.get(
            reverse('DeleteApiView', kwargs={'pk': 99,'slug':"Podcast"}))
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

#----------------------------------audiobook
class CreateNewAudiobookTest(TestCase):

    def setUp(self):
        self.valid_payload = {
            'audioFileMetadata':"{'ID':102111,'name':'c','duration':1010,'author':'ee','narrator':'I'}",'audioFileType':'Audiobook'
        }
        self.invalid_payload = {
             'audioFileMetadata':{'ID':102111,'name':'c','duration':1010,'host':'ee'},'audioFileType':'Audiobooks'
        }

    def test_create_valid(self):
        response = client.post(
            reverse('CreateApiView'),
            data=json.dumps(self.valid_payload),
            content_type='application/json'
        )
        
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_create_invalid(self):
        response = client.post(
            reverse('CreateApiView'),
            data=json.dumps(self.invalid_payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)