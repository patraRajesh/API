from django.apps import AppConfig


class MusicApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'music_api'
